import base64
import json
import os
import pandas as pd
from openpyxl import Workbook
from datetime import datetime

def append_jsonl(path, new_items):

    """
    new_items 可以是单个 dict 或 list[dict]
    """
    with open(path, 'a', encoding='utf-8') as f:
        for item in (new_items if isinstance(new_items, list) else [new_items]):
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

def ensure_excel_exists(file_path):
    """
    如果 file_path 指定的 Excel 文件不存在，则创建一个空文件。
    :param file_path: str, Excel 文件完整路径
    """
    if not os.path.exists(file_path):
        
        # 创建一个空工作簿并保存
        wb = Workbook()
        wb.save(file_path)
        print(f"已创建空 Excel 文件：{file_path}")
    else:
        print(f"文件已存在：{file_path}")

def excelUpdate(file_path,fileName,pageSize,fileContent):

    ensure_excel_exists(file_path)

    df_existing = pd.read_excel(file_path)

        # 准备要追加的数据（以字典形式）
        # 获取当前时间
    current_time = datetime.now()
    # 格式化输出
    new_data = {
        "文档名称": [fileName],
        "页码": [pageSize],
        "文本内容": [f"{fileContent}"]
    }

    # 将新数据转换为 DataFrame
    df_new = pd.DataFrame(new_data)

    # 将新数据追加到现有数据
    df_combined = pd.concat([df_existing, df_new], ignore_index=True)

    # 保存到新的 Excel 文件
    df_combined.to_excel(file_path, index=False)

def export(file_path,fileName,pageSize,content,imageBase64Str):

    pageSizeNum = pageSize.replace("page_","")

    # print(imageBase64Str)
    # 格式化输出
    new_data = {
        "fileName": fileName,
        "pageSize": pageSizeNum,
        "fileContent": f"{content}",
        "fileImage": imageBase64Str,
        "fileImageType":"png"
    }

    append_jsonl(file_path,new_data)

    excelUpdate(file_path.replace("jsonl","xlsx"),fileName,pageSize=pageSize,fileContent=f"{content}")

    

if __name__ == "__main__":

    export("test.jsonl","资产","page_1","测试","base64")