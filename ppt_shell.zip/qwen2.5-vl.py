# coding: utf-8
# Install this package at first: python -m pip install websocket-client
import json
from datetime import datetime
import aiohttp
import ssl
import asyncio
import base64

from PyPDF2 import PdfReader, PdfWriter
from pdf2image import convert_from_path
import os
import time

import excel_json_export as eje


class FlamesChatClient(object):
    # 初始化
    def __init__(self, app_id, app_secret, base_url):
        self.app_id = app_id
        self.app_secret = app_secret
        self.base_url = base_url

    # 生成url,拼接大模型接口鉴权签名信息
    def create_headers(self):
        
        # 将请求的鉴权参数组合为字典
        v = {"authorization": f"Bearer {self.app_id}:{self.app_secret}", "Content-Type": "application/json; charset=UTF-8"}
        return v

    # 基础调用路径
    def create_url(self):
        return self.base_url

    # 建立连接, 生成内容
    async def generate(self, content, task_id, imageBase64, imageName):
        request_url = self.create_url()
        # print("### generate ### request_url:", request_url)
        print(f"### 当前任务 {task_id} 处理图片 {imageName}")

        data = json.dumps(
            gen_params(
                content=content,
                image= f"{imageBase64}"
            )
        )

        # print("request is: ", data)

        headers = self.create_headers()

        ssl_context = ssl.create_default_context()

        # 忽略证书
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        startTime = datetime.now()
        print(f"任务{task_id}开始时间{startTime}")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    request_url,
                    data=data,
                    headers=headers,
                    ssl=ssl_context
                ) as response:
                    # 判断是否流式输出
                    # assert response.content_type == "text/event-stream"
                    print("response_content_type: ", response.content_type)
                    
                    if response.status != 200:
                        error_text = await response.text()
                        print(f"请求失败，状态码: {response.status}，错误信息: {error_text}")
                        return None
                    
                    async for line in response.content:
                        if line:
                            decoded_line = line.decode("utf-8").strip()
                            if decoded_line:
                                decoded_line = decoded_line.replace("data:", "")
                                try:
                                    json_data = json.loads(decoded_line)
                                    # 更健壮地获取内容
                                    content = json_data.get("choices", [{}])[0].get("message", {}).get("content", "")
                                    if isinstance(content, list) and content:
                                        content = content[0]
                                    endTime = datetime.now()
                                    print(f"{endTime} 任务{task_id}结果{content[:50]}...")  # 只打印结果前50个字符
                                    
                                    # 导出执行的结果
                                    export_name = imageName.rsplit("_page_", 1)[0]
                                    pageSizeStr = imageName.replace(f"{export_name}_","").replace(".png","")
                                    eje.export(f"{export_name}文本提取结果.jsonl",imageName,pageSize=pageSizeStr,content=content,imageBase64Str=imageBase64)
                                    return content
                                except json.JSONDecodeError as e:
                                    print(f"JSON解析错误: {e}, 原始数据: {decoded_line[:100]}...")
                                    return None
        except Exception as e:
            print(f"请求异常: {e}")
            return None


# 生成请求参数
def gen_params(content, image):
    data = {
        "model": "qwen2_5_vl",
        "messages": [
            {
            "role": "system",
            "content": "You are a helpful assistant."
            },
            {
            "role": "user", 
            "content": content, 
            "image": f"{image}"
            }
        ]
    }
    return data

def split_pdf(input_pdf_path, output_dir):
    """按页拆分单个PDF文件"""
    try:
        # 创建PDF阅读器和写入器对象
        reader = PdfReader(input_pdf_path)
        total_pages = len(reader.pages)
        
        # 获取原始文件名（不带扩展名）
        base_name = os.path.splitext(os.path.basename(input_pdf_path))[0]
        
        # 为每个页面创建一个新的PDF
        for page_num in range(total_pages):
            writer = PdfWriter()
            writer.add_page(reader.pages[page_num])
            page_num_str = ""
            if page_num < 9:
                page_num_str = f"0{page_num + 1}"
            else :
                page_num_str = f"{page_num + 1}"
            # 构建输出文件名
            output_filename = f"{base_name}_page_{page_num_str}.pdf"
            output_path = os.path.join(output_dir, output_filename)

           
            # 写入并保存新的PDF文件
            with open(output_path, 'wb') as output_pdf:
                writer.write(output_pdf)
            
            print(f"已创建: {output_filename}")
            time.sleep(0.2)
             # 单pdf转为图片
            poppler_path = f"E:/tools/poppler-23.08.0/Library/bin"
            convert_from_path(output_path, dpi=150, first_page=1, last_page=1, poppler_path=poppler_path)[0].save(output_path.replace(".pdf",".png"))
                    
        print(f"成功拆分 {input_pdf_path}，共 {total_pages} 页")
        
    except Exception as e:
        print(f"处理文件 {input_pdf_path} 时出错: {str(e)}")

def dealPdf(input_dir,output_dir):
    
    # 检查输入文件夹是否存在
    if not os.path.exists(input_dir):
        print(f"错误: 输入文件夹 '{input_dir}' 不存在")
        return
    
    # 检查输出文件夹是否存在，不存在则创建
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"已创建输出文件夹: {output_dir}")
    
    # 获取所有PDF文件
    pdf_files = [f for f in os.listdir(input_dir) if f.lower().endswith('.pdf')]
    
    if not pdf_files:
        print(f"错误: 在文件夹 '{input_dir}' 中未找到PDF文件")
        return
    
    # 处理每个PDF文件
    for pdf_file in pdf_files:
        pdf_path = os.path.join(input_dir, pdf_file)
        print(f"\n正在处理: {pdf_file}")
        split_pdf(pdf_path, output_dir)
    
    print(f"\n处理完成！共处理 {len(pdf_files)} 个PDF文件")

import os
import shutil

def clear_folder(folder_path):
    """清空文件夹：删除所有文件和子文件夹，但保留文件夹本身"""
    if not os.path.exists(folder_path):
        print(f"路径不存在: {folder_path}")
        return

    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)  # 删除文件或符号链接
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)  # 删除子文件夹
        except Exception as e:
            print(f"删除失败: {file_path}，原因: {e}")

async def run_concurrent_tasks(client, content, imageBase64Arr, imageNameArr, current_Num, num_tasks=3):
    tasks = [client.generate(content, task_id=f"{current_Num + i}", imageBase64=imageBase64Arr[i], imageName=imageNameArr[i]) for i in range(num_tasks)]
    results = await asyncio.gather(*tasks)
    return results

# 入口函数
if __name__ == "__main__":

    # 文档处理，经pdf拆分
    input_dir = "data"
    output_dir = "data_out"

    # 清空输出文件夹
    clear_folder(output_dir)

    # # 拆分原始pdf文件    
    dealPdf(input_dir, output_dir)

    image_dir = output_dir

    image_files = []
    if not os.path.exists(image_dir):
        print(f"错误: 输入文件夹 '{image_dir}' 不存在")
    else:
        image_files = [f for f in os.listdir(image_dir) if f.lower().endswith('.png')]
        if not image_files:
            print(f"错误: 在文件夹 '{image_dir}' 中未找到png图片文件")
    
    # 公共测试
    APP_ID = "20250703AN154649umiy"
    APP_SECRET = "ED1552635E2E4BE98B088BD31ED4F2E2"

    BASE_URL = "https://hecc.ai.cnooc:30016/openapi/u2gmps75"

    if image_files:
        # 将所有图片转为base64,存在字典中
        imageDict = {}
        for image_file in image_files:
            image_path = os.path.join(image_dir, image_file)
            # 读取图片内容,转为base64
            imageBase64Str = ""
            with open(image_path, 'rb') as image:
                # 将图片数据编码为 base64 字节
                encoded_bytes = base64.b64encode(image.read())
                # 将字节转为字符串（UTF-8 编码）
                imageBase64Str = encoded_bytes.decode('utf-8')
                imageDict[image_file.replace(".png","")]=imageBase64Str
        
        prompt_content = ""
        with open('prompt.txt', 'r', encoding='utf-8') as file:
            prompt_content = file.read()
        content = prompt_content
        print(f"提示词{content}")
        imageNum = len(image_files)
        i = 1
        while i <= imageNum:
            client = FlamesChatClient(APP_ID, APP_SECRET, BASE_URL)

            # 并发线程数
            num_tasks = 2

            imageKeys = imageDict.keys()
            keys_list = list(imageKeys)
            if i -1 + num_tasks > imageNum:
                num_tasks = imageNum - i + 1

            imageNameArr = keys_list[i-1:i+num_tasks-1]
            # 修正：传递正确的imageBase64Arr
            imageBase64Arr = [imageDict[key] for key in imageNameArr]
            
            # 创建异步任务
            tasks = run_concurrent_tasks(
                client=client,
                content=content,
                imageBase64Arr=imageBase64Arr, 
                imageNameArr=imageNameArr,
                current_Num=i,
                num_tasks=num_tasks
            )
            
            # 正确执行异步任务
            results = asyncio.run(tasks)
            i = i + num_tasks

            for idx, result in enumerate(results):
                if result:
                    print(f"\nTask {idx+1} ({imageNameArr[idx]}) 结果: {result[:100]}...")
                else:
                    print(f"\nTask {idx+1} ({imageNameArr[idx]}) 失败或无结果")