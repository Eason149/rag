
import uuid
import json
import json
import os
import requests
import uuid
import os

class FlamesChatClient(object):

    # 初始化
    def __init__(self, app_id, app_secret, base_url):
        self.app_id = app_id
        self.app_secret = app_secret
        self.base_url = base_url
        # chat会话接口地址
        self.chat_endpoint = "/openapi/flames/api/v2/chat"
        # 文件上传接口地址
        self.upload_endpoint = "/openapi/flames/file/v2/upload"

    def create_url(self, method, path, wsProtocol):
        base_url = self.base_url.replace("https", "wss").replace("http", "ws") if wsProtocol else self.base_url
        # 拼接鉴权参数，生成url
        url = base_url + path
        # 此处打印出建立连接时候的url,参考本demo的时候可取消上方打印的注释，比对相同参数时生成的url与自己代码生成的url是否一致
        return url

    def createHeader(self):
        authorization_origin = f"Bearer {self.app_id}:{self.app_secret}"

        # 将请求的鉴权参数组合为字典
        v = {"authorization": authorization_origin,"Content-Type": "application/json"}
        return v


    def upload(self, file_name,file_base64_str):
        request_url = self.create_url("POST", self.upload_endpoint, False)
        print("### upload ### request_url:", request_url)
        body = {
            "payload": {
                "fileName": file_name,
                "file": file_base64_str
            }
        }
        headers = self.createHeader()

        response = requests.post(request_url, json=body, headers=headers,

                                 verify=False)
        print('response:', response.text)
        data = json.loads(response.text)
        code = data["header"]["code"]
        if code != 0:
            print(f'请求错误: {code}, {data}')
            return
        else:
            file_id = data["payload"]["id"]
        return file_id

# 生成文档id
def generageDocId():
    uuid_36 = uuid.uuid4()
    uuid_32 = str(uuid_36).replace('-', '')
    return uuid_32

# 生成知识块id
def generageId():
    uuid_36 = uuid.uuid4()
    uuid_32 = str(uuid_36).replace('-', '')
    return uuid_32

def generateRequestBody(id, docId,docName,docType,imageFileId,fileContent):

    # 读取配置文件
    jsonData = {}
    with open('application.json', 'r', encoding='utf-8') as file:
    # 解析 JSON 数据为 Python 对象
        jsonData = json.load(file)
   
    # 配置分类id
    categoryID = jsonData.get("categoryID","")
    # 配置知识库id
    libId = jsonData.get("libId","")
    # 生成知识块id
    paragraphId = generageId()

    body = {
        "autoPublish": 1,
        "categoryID":categoryID,
        "docId": docId,
        "documentParagraphList": [
            {
                "autoPublish": True,
                "content": f"{fileContent}",
                "docName": f"{docName}",
                "fileExtension": docType,
                "html": f" {fileContent} \n <img src=\"/proxyApi/flames-docqa/doc/semantic-doc/document/preview?filePath={imageFileId}\" width=\"800\" height=\"550\" alt=\"\" style=\"\">\n",
                "id": paragraphId,
                "paths": [
                    docName
                ],
                "reference": {
                    "unused1": {
                        "content": "base64",
                        "format": "img",
                        "link": f"/proxyApi/flames-docqa/doc/semantic-doc/document/preview?filePath={imageFileId}&wh=800*550",
                        "suffix": ""
                    }
                },
                "sheetName": "",
                "showText": f"{docName}:{fileContent}",
                "splitContent": [
                    f"{docName}:{fileContent}"
                ],
                "title": "",
                "type": [
                    "text"
                ]
            }
        ],
        "fileType": "text",
        "id": id,
        "knowledgeType": 1,
        "labels": [],
        "libId": libId,
        "name": docName,
        "preview": False,
        "splitType": 7,
        "version": 2
    }
    return body

def uploadRequest(requestBody):
    #  print(requestBody)
     request_url = "http://10.74.1.6:2020/ceshi/doc/semantic-doc/document/addDocumentAndPara"
     headers = {"Content-Type":"application/json"}
     response = requests.post(request_url, json=requestBody, headers=headers,
                                 verify=False)
     print('response:', response.text)

if __name__ == '__main__':

    # 读取配置文件
    jsonData = {}
    with open('application.json', 'r', encoding='utf-8') as file:
    # 解析 JSON 数据为 Python 对象
        jsonData = json.load(file)

    APP_ID = jsonData["appId"]
    APP_SECRET = jsonData["appSecret"]
    BASE_URL = "https://agents.ai.cnooc:30009"

    client = FlamesChatClient(APP_ID, APP_SECRET, BASE_URL)

    jsonl_dir = './data'
    jsonl_files = []
    if not os.path.exists(jsonl_dir):
        print(f"错误: 输入文件夹 '{jsonl_dir}' 不存在")
    else:
        jsonl_files = [f for f in os.listdir(jsonl_dir) if f.lower().endswith('.jsonl')]
        if not jsonl_files:
            print(f"错误: 在文件夹 '{jsonl_dir}' 中未找到jsonl文件")
    if(jsonl_files):
        for jsonl_file in jsonl_files:

            print("当前文件：",jsonl_file)
            dataArr = []
            with open(os.path.join(jsonl_dir, jsonl_file), 'r', encoding='utf-8') as file:
                for line in file:
                    data = json.loads(line)
                    dataArr.append(data)
            
            sorted_data_arr = sorted(dataArr, key=lambda x: x["pageSize"])
            # 文档id使用的是id,初始化文档时，id自动生成
            id = generageId()
            #docid作用未知
            docId = generageId()
            for one_data in sorted_data_arr:
                file_name = one_data["fileName"]
                file_page_size = one_data["pageSize"]
                # print(file_name + "-" + fiel_page_size)
                image_file_name = f"{one_data["fileName"]}_{file_page_size}.png"
                # print(image_file_name)
                file_base64_str = f"{one_data["fileImage"]}"
                # 上传文件得到file文件id
                file_id = client.upload(image_file_name,file_base64_str)
                # 文档名称
                docName = f"{one_data["fileName"].rsplit("_page_", 1)[0]}.pdf"
                docType = "pdf"
                # 知识块中插入的图片id
                imageFileId = file_id
                # 知识块文本内容
                fileContent = one_data["fileContent"]
                body = generateRequestBody(id, docId,docName,docType,imageFileId,fileContent)
                arr = [body]
                uploadRequest(arr)
                # break








